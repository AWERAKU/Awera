# AWERA
Netflix-style video app with real-time comments, admin dashboard, and analytics.

## Setup
1. Copy `.env.example` → `.env` and add your Firebase keys
2. Run `npm install`
3. Start dev server: `npm run dev`

## Deployment
Use Vercel: connect this repo, add `.env`, and deploy.