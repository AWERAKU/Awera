// Main App Component
export default function App() { return <h1>AWERA App</h1>; }